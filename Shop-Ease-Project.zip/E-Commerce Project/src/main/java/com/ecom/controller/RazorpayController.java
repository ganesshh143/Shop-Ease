package com.ecom.controller;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

@RestController
public class RazorpayController {

    @Value("${razorpay.key_id}")
    private String razorpayKeyId;

    @Value("${razorpay.key_secret}")
    private String razorpayKeySecret;

    // ✅ Create Razorpay Order
    @PostMapping("/create-order")
    public String createOrder(@RequestBody PaymentRequest request) {
        try {
            RazorpayClient client = new RazorpayClient("rzp_test_RWdGDsXZ0bVInW", "CIdnCIcIrvH0U1AyDcncPDuD");

            JSONObject orderRequest = new JSONObject();
            orderRequest.put("amount", request.getAmount() * 100); // Convert ₹ to paise
            orderRequest.put("currency", "INR");
            orderRequest.put("receipt", "txn_" + System.currentTimeMillis());
            orderRequest.put("payment_capture", 1); // Auto capture

            Order order = client.orders.create(orderRequest);

            JSONObject response = new JSONObject();
            response.put("id", order.get("id").toString());
            response.put("amount", Integer.parseInt(order.get("amount").toString()));
            response.put("currency", order.get("currency").toString());
            response.put("key", razorpayKeyId);

            return response.toString();

        } catch (Exception e) {
            e.printStackTrace();
            return "{\"error\":\"" + e.getMessage() + "\"}";
        }
    }

    // ✅ Verify Razorpay Payment Signature
    @PostMapping("/verify-payment")
    public String verifyPayment(@RequestBody PaymentResponse payment) {
        try {
            String orderId = payment.getRazorpay_order_id();
            String paymentId = payment.getRazorpay_payment_id();
            String signature = payment.getRazorpay_signature();

            String data = orderId + "|" + paymentId;
            String generatedSignature = hmacSHA256(data, razorpayKeySecret);

            boolean isValid = generatedSignature.equals(signature);
            return "{\"valid\": " + isValid + "}";

        } catch (Exception e) {
            e.printStackTrace();
            return "{\"error\":\"" + e.getMessage() + "\"}";
        }
    }

    // ✅ Securely generate HMAC SHA256 signature
    private String hmacSHA256(String data, String secret) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        SecretKeySpec secretKeySpec = new SecretKeySpec(secret.getBytes("UTF-8"), "HmacSHA256");
        mac.init(secretKeySpec);
        byte[] hashBytes = mac.doFinal(data.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte b : hashBytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}

// ✅ DTO: PaymentRequest
class PaymentRequest {
    private int amount;
    public int getAmount() { return amount; }
    public void setAmount(int amount) { this.amount = amount; }
}

// ✅ DTO: PaymentResponse
class PaymentResponse {
    private String razorpay_payment_id;
    private String razorpay_order_id;
    private String razorpay_signature;

    public String getRazorpay_payment_id() { return razorpay_payment_id; }
    public void setRazorpay_payment_id(String razorpay_payment_id) { this.razorpay_payment_id = razorpay_payment_id; }

    public String getRazorpay_order_id() { return razorpay_order_id; }
    public void setRazorpay_order_id(String razorpay_order_id) { this.razorpay_order_id = razorpay_order_id; }

    public String getRazorpay_signature() { return razorpay_signature; }
    public void setRazorpay_signature(String razorpay_signature) { this.razorpay_signature = razorpay_signature; }
}
