// ==============================
// ✅ E-Commerce Frontend Scripts
// ==============================

$(function () {

  // ----------------------------
  // ✅ User Registration Validation
  // ----------------------------

  const $userRegister = $("#userRegister");

  $userRegister.validate({
    rules: {
      name: { required: true, lettersonly: true },
      email: { required: true, email: true },
      mobileNumber: { required: true, numericOnly: true, minlength: 10, maxlength: 12 },
      password: { required: true },
      confirmpassword: { required: true, equalTo: "#pass" },
      address: { required: true },
      city: { required: true },
      state: { required: true },
      pincode: { required: true, numericOnly: true },
      img: { required: true }
    },
    messages: {
      name: { required: "Name is required", lettersonly: "Invalid name" },
      email: { required: "Email is required", email: "Invalid email" },
      mobileNumber: {
        required: "Mobile number required",
        numericOnly: "Invalid number",
        minlength: "Must be 10 digits",
        maxlength: "Max 12 digits"
      },
      password: { required: "Password is required" },
      confirmpassword: {
        required: "Confirm your password",
        equalTo: "Passwords do not match"
      },
      address: { required: "Address required" },
      city: { required: "City required" },
      state: { required: "State required" },
      pincode: { required: "Pincode required", numericOnly: "Invalid pincode" },
      img: { required: "Please upload an image" }
    }
  });

  // ----------------------------
  // ✅ Orders Page Validation
  // ----------------------------

  const $orders = $("#orders");

  $orders.validate({
    rules: {
      firstName: { required: true, lettersonly: true },
      lastName: { required: true, lettersonly: true },
      email: { required: true, email: true },
      mobileNo: { required: true, numericOnly: true, minlength: 10, maxlength: 12 },
      address: { required: true },
      city: { required: true },
      state: { required: true },
      pincode: { required: true, numericOnly: true },
      paymentType: { required: true }
    },
    messages: {
      firstName: { required: "First name required" },
      lastName: { required: "Last name required" },
      email: { required: "Email required", email: "Invalid email" },
      mobileNo: {
        required: "Mobile number required",
        numericOnly: "Invalid number",
        minlength: "Must be 10 digits",
        maxlength: "Max 12 digits"
      },
      address: { required: "Address required" },
      city: { required: "City required" },
      state: { required: "State required" },
      pincode: { required: "Pincode required", numericOnly: "Invalid pincode" },
      paymentType: { required: "Select a payment type" }
    }
  });

  // ----------------------------
  // ✅ Reset Password Validation
  // ----------------------------

  const $resetPassword = $("#resetPassword");

  $resetPassword.validate({
    rules: {
      password: { required: true },
      confirmPassword: { required: true, equalTo: "#pass" }
    },
    messages: {
      password: { required: "Password is required" },
      confirmPassword: {
        required: "Confirm your password",
        equalTo: "Passwords do not match"
      }
    }
  });

  // ----------------------------
  // ✅ Razorpay Payment Integration
  // ----------------------------

  const placeOrderBtn = document.getElementById("placeOrderBtn");
  const orderForm = document.getElementById("orders");

  if (placeOrderBtn) {
    placeOrderBtn.addEventListener("click", async function () {
      const paymentType = document.getElementById("paymentType").value;
      const totalAmount = window.totalOrderPrice || 0;

      if (!paymentType) {
        alert("Please select a payment type.");
        return;
      }

      // --- 🏠 Cash on Delivery ---
      if (paymentType === "COD") {
        orderForm.submit();
        return;
      }

      // --- 💳 Online Payment (Razorpay) ---
      if (paymentType === "ONLINE") {
        try {
          console.log("🧾 Creating Razorpay order for:", totalAmount);

          const response = await fetch("/create-order", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ amount: totalAmount })
          });

          if (!response.ok) {
            throw new Error("Server returned " + response.status);
          }

          const orderData = await response.json();
          console.log("✅ Order created:", orderData);

          const options = {
            key: "rzp_test_RWdGDsXZ0bVInW",
            amount: orderData.amount,
            currency: orderData.currency,
            name: "ShopEase",
            description: "Online Purchase",
            order_id: orderData.id,
            handler: async function (paymentResponse) {
              console.log("💳 Payment Success:", paymentResponse);
              alert("Payment Successful! ID: " + paymentResponse.razorpay_payment_id);

              // Verify Payment on Server
              await fetch("/verify-payment", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(paymentResponse)
              });

              // Save order
              orderForm.submit();
            },
            prefill: {
              name:
                document.querySelector("[name=firstName]").value +
                " " +
                document.querySelector("[name=lastName]").value,
              email: document.querySelector("[name=email]").value,
              contact: document.querySelector("[name=mobileNo]").value
            },
            theme: { color: "#0d6efd" }
          };

          const rzp = new Razorpay(options);
          rzp.open();
        } catch (error) {
          console.error("❌ Payment Error:", error);
          alert("Something went wrong during payment.");
        }
      }
    });
  }

  // ----------------------------
  // ✅ jQuery Validator Custom Methods
  // ----------------------------

  jQuery.validator.addMethod("lettersonly", function (value, element) {
    return /^[a-zA-Z\s]+$/.test(value);
  });

  jQuery.validator.addMethod("numericOnly", function (value, element) {
    return /^[0-9]+$/.test(value);
  });
});
